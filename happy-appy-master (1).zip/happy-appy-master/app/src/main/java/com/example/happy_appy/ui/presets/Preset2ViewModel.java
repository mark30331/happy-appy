package com.example.happy_appy.ui.presets;

import androidx.lifecycle.ViewModel;

public class Preset2ViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
