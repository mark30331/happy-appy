package com.example.happy_appy.ui.presets;

import androidx.lifecycle.ViewModel;

public class Preset3ViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
