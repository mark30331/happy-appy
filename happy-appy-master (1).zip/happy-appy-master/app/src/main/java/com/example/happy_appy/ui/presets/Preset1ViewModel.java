package com.example.happy_appy.ui.presets;

import android.app.Activity;

import androidx.lifecycle.ViewModel;

import com.example.happy_appy.R;

public class Preset1ViewModel extends ViewModel {
    // TODO: Implement the ViewModel
    void onCreate(){


    }
}
