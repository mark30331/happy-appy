package com.example.happy_appy.ui.music;

import androidx.lifecycle.ViewModel;

public class MusicViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
