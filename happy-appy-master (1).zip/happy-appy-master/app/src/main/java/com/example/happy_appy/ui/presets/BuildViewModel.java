package com.example.happy_appy.ui.presets;

import androidx.lifecycle.ViewModel;

public class BuildViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
